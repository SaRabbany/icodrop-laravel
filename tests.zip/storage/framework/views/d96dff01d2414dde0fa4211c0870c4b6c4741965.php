<?php $__env->startSection('content'); ?>

<section class="home-card-section">
    <div class="container cards-row">
        <div class="active-ico cards">
            <div class="title">
                <h2>ACTIVE ICO</h2>
            </div>



            <?php $__currentLoopData = $active; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $active_card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <a href="<?php echo e(route('singleCard', $active_card->id)); ?>">
                <div class="card">
                    <div class="upper d-flex">
                        <div class="image">
                            <img src="<?php echo e($active_card->logo); ?>" alt="">
                        </div>
                        <div class="info">
                            <div class="name">
                                <h5><?php echo e($active_card->name); ?></h5>
                            </div>
                            <div class="service-name">
                                <span> <?php echo e($active_card->service_type); ?></span>
                            </div>
                            <div class="money d-flex">
                                <div class="received">
                                    <span>$<?php echo e($active_card->price); ?> </span>
                                </div>
                                <div class="total">
                                    <span>/ $<?php echo e($active_card->previous_price); ?></span>
                                </div>
                            </div>
                            <div class="percentage">
                                <span><?php echo e($active_card->diffrent_parcent); ?>%</span>
                            </div>
                        </div>
                    </div>
                    <div class="bottom">
                        <div class="rate-time d-flex justify-content-between">
                            <div class="rate">
                                <span>Not Rated</span>
                            </div>
                            <div class="timeLeft">

                                <?php
                                $different_days = \Carbon\Carbon::parse($active_card->sale_start)->diffInDays($active_card->sale_end);

                                ?>
                                <span> <?php echo e($different_days); ?> day left </span>
                            </div>
                        </div>
                    </div>
                </div>
            </a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(!$active->isEmpty()): ?>
            <div class="page-redirect-btn">
                <button>
                    <a href="<?php echo e(route('active_ico')); ?>">VIEW ALL ACTIVE ICO</a>
                </button>
            </div>
            <?php endif; ?>


        </div>


        <div class="upcoming-ico cards">
            <div class="title">
                <h2>UPCOMING ICO</h2>
            </div>



            <?php $__currentLoopData = $UpComing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $UpComing_card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <a href="<?php echo e(route('singleCard', $UpComing_card->id)); ?>">
                <div class="card">
                    <div class="upper d-flex">
                        <div class="image">
                            <img src="<?php echo e($UpComing_card->logo); ?>" alt="">
                        </div>
                        <div class="info">
                            <div class="name">
                                <h5><?php echo e($UpComing_card->name); ?></h5>
                            </div>
                            <div class="service-name">
                                <span> <?php echo e($UpComing_card->service_type); ?></span>
                            </div>
                            <div class="money d-flex">
                                <div class="received">
                                    <span>$<?php echo e($UpComing_card->price); ?> </span>
                                </div>
                                <div class="total">
                                    <span>/ $<?php echo e($UpComing_card->previous_price); ?></span>
                                </div>
                            </div>
                            <div class="percentage">
                                <span><?php echo e($UpComing_card->diffrent_parcent); ?>%</span>
                            </div>
                        </div>
                    </div>
                    <div class="bottom">
                        <div class="rate-time d-flex justify-content-between">
                            <div class="rate">
                                <span>Not Rated</span>
                            </div>
                            <div class="timeLeft">

                                <?php
                                $different_days = \Carbon\Carbon::parse($UpComing_card->sale_start)->diffInDays($UpComing_card->sale_end);

                                ?>
                                <span> <?php echo e($different_days); ?> day left </span>
                            </div>
                        </div>
                    </div>
                </div>
            </a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(!$UpComing->isEmpty()): ?>
            <div class="page-redirect-btn">
                <button>
                    <a href="<?php echo e(route('UpComing_ico')); ?>">VIEW ALL Upcoming ICO</a>
                </button>
            </div>
            <?php endif; ?>

        </div>



        <div class="ended-ico cards">
            <div class="title">
                <h2>ENDED ICO</h2>
            </div>



            <?php $__currentLoopData = $Ended; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Ended_card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <a href="<?php echo e(route('singleCard', $Ended_card->id)); ?>">
                <div class="card">
                    <div class="upper d-flex">
                        <div class="image">
                            <img src="<?php echo e($Ended_card->logo); ?>" alt="">
                        </div>
                        <div class="info">
                            <div class="name">
                                <h5><?php echo e($Ended_card->name); ?></h5>
                            </div>
                            <div class="service-name">
                                <span> <?php echo e($Ended_card->service_type); ?></span>
                            </div>
                            <div class="money d-flex">
                                <div class="received">
                                    <span>$<?php echo e($Ended_card->price); ?> </span>
                                </div>
                                <div class="total">
                                    <span>/ $<?php echo e($Ended_card->previous_price); ?></span>
                                </div>
                            </div>
                            <div class="percentage">
                                <span><?php echo e($Ended_card->diffrent_parcent); ?>%</span>
                            </div>
                        </div>
                    </div>
                    <div class="bottom">
                        <div class="rate-time d-flex justify-content-between">
                            <div class="rate">
                                <span>Not Rated</span>
                            </div>
                            <div class="timeLeft">

                                <?php
                                $different_days = \Carbon\Carbon::parse($Ended_card->sale_start)->diffInDays($Ended_card->sale_end);
                                ?>
                                <span> <?php echo e($different_days); ?> day left </span>
                            </div>
                        </div>
                    </div>
                </div>
            </a>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(!$Ended->isEmpty()): ?>
            <div class="page-redirect-btn">
                <button>
                    <a href="<?php echo e(route('Ended_ico')); ?>">VIEW ALL Ended ICO</a>
                </button>
            </div>

            <?php endif; ?>


        </div>




    </div>

</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\fiverr\icodrop-laravel\resources\views/index.blade.php ENDPATH**/ ?>