<?php $__env->startSection('customCss'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/cardDetails/singleCard.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<section class="card-details">
    <div class="container">
        <?php if(!is_null($card->importand_notice)): ?>
        <div class="card message-card">
            <p><span class="important">Important: </span><?php echo e($card->importand_notice); ?> </p>
        </div>
        <?php endif; ?>
        <div class="card details-cards">
            <div class="img-and-details d-flex">
                <div class="">
                    <div class="logo-img">
                        <img src="<?php echo e($card->logo); ?>" alt="">
                    </div>
                </div>
                <div class="details">
                    <div class="name-category d-flex align-items-end">
                        <h2 class="name"><?php echo e($card->name); ?></h2>
                        <h5 class="category">(<?php echo e($card->service_type); ?>)</h5>
                    </div>
                    <div class="small-desc">
                        <?php echo e($card->description); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="card coverCard details-cards">
            <div class="card-contents">
                <div class="coverImg">
                    <img src="<?php echo e($card->banner_image); ?>" alt="">
                </div>
                <div class="side-details">
                    <div class="token-ends">

                    <?php
                        $different_days  = \Carbon\Carbon::parse($card->sale_start)->diffInDays($card->sale_end);
                    ?>
                        <span>Token Sale <b class="token-ends-in">ends in <br><?php echo e($different_days); ?> day</b></span>
                    </div>
                    <div class="money-transfer">
                        <div class="total-reveived">
                            <b>$<?php echo e($card->price); ?></b>
                        </div>
                        <h6>OF</h6>
                        <div class="total-amount">
                            <b> $<?php echo e($card->previous_price); ?> <span class="percentage">(<?php echo e($card->diffrent_parcent); ?>%)</span></b>
                        </div>
                    </div>
                    <div class="website-link mb-3">
                        <a href="<?php echo e($card->website_link); ?>"><button>Website</button></a>
                    </div>
                    <div class="whitepaper-link">
                        <a href="<?php echo e(route('whitelist')); ?>"><button>WhiteList</button></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card details-cards">
            <div class="card-titles">
                <?php
                    $startMonth =\Carbon\Carbon::parse($card->sale_start)->format('M');
                    $startDate =\Carbon\Carbon::parse($card->sale_start)->format('d');
                    $endMonth = \Carbon\Carbon::parse($card->sale_end)->format('M');
                    $enddate = \Carbon\Carbon::parse($card->sale_end)->format('d');
                ?>
                <h6>TOKEN SALE:  <?php echo e($startDate); ?>  <?php echo e($startMonth); ?> - <?php echo e($enddate); ?> <?php echo e($endMonth); ?> </h6>
            </div>

            <div class="small-details">
                <ul>
                    <?php if(!is_null($card->ticker)): ?>
                         <li>Ticker: <b><?php echo e($card->ticker); ?></b></li>
                    <?php endif; ?>

                    <li>Token type: <b><?php echo e($card->token_type); ?></b></li>
                    <li>ICO Token Price: <b>  <?php echo e($card->ico_token_price); ?></b></li>

                    <?php if(!is_null($card->usd_fund_goal)): ?>
                    <li>USDFundraising Goal: <b><?php echo e($card->usd_fund_goal); ?> TOKEN</b></li>
                    <?php endif; ?>


                    <?php if(!is_null($card->total_tokens)): ?>
                    <li>UTotal Tokens:: <b><?php echo e($card->total_tokens); ?> TOKEN</b></li>
                    <?php endif; ?>

                </ul>
            </div>
        </div>
        <div class="card details-cards">
            <div class="card-titles">
                <h6>SHORT REVIEW</h6>
            </div>

            <div class="small-details">
                <ul>
                    <li>Role of Token: <b><?php echo e($card->role_of_token); ?></b></li>
                </ul>
            </div>
        </div>
        <div class="card screenshot-cards details-cards">
            <div class="card-titles">
                <h6>SCREENSHOTS</h6>
            </div>

            <?php if(!$card->screnshots->isEmpty()): ?>
                <?php $__currentLoopData = $card->screnshots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screnshot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="screenshot-container">
                    <div class="screenshot">
                        <div class="image">
                            <img src="<?php echo e($screnshot->image); ?>" alt="">
                        </div>
                        <div class="screenshot-name">
                            <span><?php echo e($screnshot->name); ?></span>
                        </div>
                    </div>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>

            </div>
        </div>
    </div>
</section>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\fiverr\icodrop-laravel\resources\views/frontend/singleCard.blade.php ENDPATH**/ ?>