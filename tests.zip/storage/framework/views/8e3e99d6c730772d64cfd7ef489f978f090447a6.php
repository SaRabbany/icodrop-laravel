


<?php $__env->startSection('adminSection'); ?>

    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Dashboard</h1>
        </div>

        <section class="section dashboard">
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-12">
                            <div class="card recent-sales">

                                <div class="card-body">
                                    <h5 class="card-title"> All Drops </h5>

                                    <table class="table table-borderless datatable">
                                        <thead>
                                            <tr>
                                                <th scope="col">id</th>
                                                <th scope="col">Name</th>
                                                <th scope="col">Category</th>
                                                <th scope="col">Price</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $allCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                 
                                            <tr>
                                                <th scope="row"><a href="#"><?php echo e($loop->iteration); ?> </a></th>
                                                <td><?php echo e($single->name); ?></td>
                                                <td><a href="#" class="text-primary"><?php echo e($single->card_type); ?></a></td>
                                                <td>$<?php echo e($single->price); ?></td>

                                                <td>
                                                    <div class="btn-group">

                                                        <a href="<?php echo e(route('card-update', $single->id)); ?>">
                                                            <button type="button" class="btn btn-warning btn-sm" >Update</button>
                                                        </a>

                                                        <form method="POST" action="<?php echo e(route('card-delete',  $single->id )); ?> " id="delete-form-<?php echo e($single->id); ?>" style="display:none; ">
                                                            <?php echo e(csrf_field()); ?>

                                                            <?php echo e(method_field("delete")); ?>

                                                        </form>
                    
                    
                                                        <button onclick="if(confirm('are you sure to delete this')){
                                                            document.getElementById('delete-form-<?php echo e($single->id); ?>').submit();
                                                            }
                                                            else{
                                                            event.preventDefault();
                                                            }
                                                            " class="btn btn-danger btn-sm btn-raised">
                                                            Delete
                                                        </button>

                                                    </div>
                                                </td>
                                               

                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>

                                </div>

                            </div>
                        </div>

                 

                    </div>
                </div>


            </div>
        </section>

    </main>


    <?php $__env->stopSection(); ?>
    




<?php echo $__env->make('admin.includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\fiverr\icodrop-laravel\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>