




<a href="<?php echo e(route('cards.create')); ?>">create</a>
<a href="<?php echo e(route('archived')); ?>">archived drops</a>

<?php /**PATH F:\fiverr\icodrop-laravel\resources\views/admin/index.blade.php ENDPATH**/ ?>